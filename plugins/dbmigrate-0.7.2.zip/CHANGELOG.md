# Changelog

* 0.7.2
  * Update README.md with renamed project URL's
  * Create CHANGELOG.md file
  
* 0.7.1
  * Renamed references to DBMigrate to be dbmigrate to resolve a problem with case-sensitive file-systems, such as *nix

* 0.7.0
  * Update plugin compatibility for CFWheels 1.1.3, 1.1.4 and 1.1.5
  * Create update-record template that includes parameters table and example code
  * Create remove-record template that includes parameters table and example code  
  * Create add-record template that includes parameters table and example code
  * Create remove-index template that includes parameters table and example code
  * Create create-index template that includes parameters table and example code
  * Create remove-column template that includes parameters table and example code
  * Create rename-column template that includes parameters table and example code
  * Create change-column template that includes parameters table and example code
  * Create create-column template that includes parameters table and example code
  * Create remove-table template that includes parameters table and example code
  * Create rename-table template that includes parameters table and example code
  * Create create-table template that includes parameters table and example code
  * Fix problem with MySQL statements for inserting values into date/time fields